// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';


import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart' as prefix0;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:vector_math/vector_math_64.dart';
import 'CircleProgressBar.dart';
import 'container_hand.dart';
import 'drawn_hand.dart';
import 'model.dart';

/// Total distance traveled by a second or a minute hand, each second or minute,
/// respectively.
final radiansPerTick = radians(360 / 60);

/// Total distance traveled by an hour hand, each hour, in radians.
final radiansPerHour = radians(360 / 12);

/// A basic analog clock.
///
/// You can do better than this!
///
enum _Element {
  background,
  text,
  shadow,
}


/// A basic digital clock.
///
/// You can do better than this!
class DigitalClock extends StatefulWidget {
  const DigitalClock(this.model);

  final ClockModel model;

  @override
  _DigitalClockState createState() => _DigitalClockState();
}

class _DigitalClockState extends State<DigitalClock> {
  DateTime _dateTime = DateTime.now();
  Timer _timer;
  var _temperature = '';
  var _temperatureRange = '';
  var _condition = '';
  var _location = '';
  double progressPercent = 0;

  @override
  void initState() {
    super.initState();
    widget.model.addListener(_updateModel);
    _updateTime();
    _updateModel();
  }

  @override
  void didUpdateWidget(DigitalClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    widget.model.dispose();
    super.dispose();
  }

  void _updateModel() {
    setState(() {
      _temperature = widget.model.temperatureString;
      _temperatureRange = '(${widget.model.low} - ${widget.model.highString})';
      _condition = widget.model.weatherString;
      _location = widget.model.location;
    });
  }

  void _updateTime() {
    setState(() {
      _dateTime = DateTime.now();

      // Update once per minute. If you want to update every second, use the
      // following code.
      /*_timer = Timer(
        Duration(minutes: 1) -0
            Duration(seconds: _dateTime.second) -
            Duration(milliseconds: _dateTime.millisecond),
        _updateTime,
      );*/
      // Update once per second, but make sure to do it at the beginning of each
      // new second, so that the clock is accurate.
         _timer = Timer(
         Duration(seconds: 1) - Duration(milliseconds: _dateTime.millisecond),
          _updateTime,
       );


      if(progressPercent>1)
      {
        progressPercent=0;
      }
      else
      {
        progressPercent= (progressPercent + 1);
      }

    });
  }

  @override
  Widget build(BuildContext context) {
    // There are many ways to apply themes to your clock. Some are:
    //  - Inherit the parent Theme (see ClockCustomizer in the
    //    flutter_clock_helper package).
    //  - Override the Theme.of(context).colorScheme.
    //  - Create your own [ThemeData], demonstrated in [AnalogClock].
    //  - Create a map of [Color]s to custom keys, demonstrated in
    //    [DigitalClock].

    double width = 420;
    final customTheme = Theme.of(context).brightness == Brightness.light
        ? Theme.of(context).copyWith(
      // Hour hand.
      primaryColor: Color(0xffCCD8EA),
      // Minute hand.
      highlightColor: Color(0xffCCD8EA),
      // Second hand.
      accentColor: Color(0xffDAA926),
      backgroundColor: Color(0xFFD2E3FC),
    )
        : Theme.of(context).copyWith(
      primaryColor: Color(0xFFD2E3FC),
      highlightColor: Color(0xFF4285F4),
      accentColor: Color(0xFF8AB4F8),
      backgroundColor: Color(0xFF3C4043),
    );

    final time = DateFormat.Hms().format(DateTime.now());
    final weatherInfo = DefaultTextStyle(
      style: TextStyle(color: Color(0xffaaaaaa)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_temperature),
          Text(_temperatureRange),
          Text(_condition),
          Text(_location),
        ],
      ),
    );

    final Shader linearGradient = LinearGradient(
      colors: <Color>[Color(0xff2C4968),Color(0xff2C4968)],
    ).createShader(Rect.fromLTWH(50.0, 0.0, 200.0, 70.0));
    final hour =
        DateFormat(widget.model.is24HourFormat ? 'hh' : 'HH').format(_dateTime);
    final minute = DateFormat('mm').format(_dateTime);
    final day = DateFormat('E d').format(_dateTime);
    final second = DateFormat('s a').format(_dateTime);
    final fontSize = MediaQuery.of(context).size.width / 3.5;


    return Stack(children: <Widget>[
        new Container(
         color: Color(0xff2C4968),
        ),
        Center(
          child:new Container(
            width: width - 150,
            height: width - 150,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xff2C4968)),
          ),
        ),

        Center(child:new Container(
          width: width - 120,
          height: width - 120,
            child:new CircleProgressBar(
              backgroundColor: Color(0xff1D3249),
              foregroundColor: Color(0xffDAA926),
              value: progressPercent,
            )
      )),
        Center(child:new Container(
          width: width - 160,
          height: width - 160,
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xFF0ff20334A)),
          child:new Column(children: <Widget>[
            Text("12",style: new TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.none,
                color: Color(0xffaaaaaa)),),
            Container(
              margin:EdgeInsets.fromLTRB(0, (width-170)/2 - 20, 0, 0),
              alignment: Alignment.center,
              child:new Row(
                children: <Widget>[
                  Text("9",style: new TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.none,
                  color: Color(0xffaaaaaa)),),
                  Spacer(),
                  Text("3",style: new TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.none,
                  color: Color(0xffaaaaaa)),),
            ],),),
            Spacer(),
            Text("6",style: new TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.none,
                color: Color(0xffaaaaaa)),),
          ],)
        ),
      ),
      new Container(
          alignment: Alignment.center,
          margin:EdgeInsets.fromLTRB(0, 0, 0, 0),
          child:new Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Text(hour,style: new TextStyle(
                          fontSize: 60.0,
                          fontWeight: FontWeight.bold,
                          decoration: TextDecoration.none,
                          fontFamily: 'Digital_Dismay',
                          letterSpacing: 6,
                          foreground: Paint()..shader = linearGradient),),
                      Text(":",style: new TextStyle(
                          fontSize: 60.0,
                          fontWeight: FontWeight.bold,
                          decoration: TextDecoration.none,
                          fontFamily: 'Digital_Dismay',
                          letterSpacing: 6,
                          foreground: Paint()..shader = linearGradient),),
                      Text(minute,style: new TextStyle(
                          fontSize: 60.0,
                          fontWeight: FontWeight.bold,
                          decoration: TextDecoration.none,
                          fontFamily: 'Digital_Dismay',
                          letterSpacing: 6,
                          foreground: Paint()..shader = linearGradient),),
                      new Container(
                        width: 34,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(3.0),
                        child: Text(second.toUpperCase(),style: new TextStyle(
                            fontSize: 16.0,
                            letterSpacing: 2,
                            decoration: TextDecoration.none,
                            color: Color(0xff2C4968)),
                        ),
                      )
                    ],
                  )
              ),
              new Container(
                margin:EdgeInsets.fromLTRB(100, 50, 0, 0),
                padding: const EdgeInsets.all(3.0),
                decoration: BoxDecoration(
                    borderRadius: new BorderRadius.all(new Radius.circular(10.0)),
                    border: Border.all(color: Color(0xff98761a),width: 2)
                ),
                child: Text(day.toUpperCase(),style: new TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.none,
                  color: Color(0xff98761a),
                ),),
              ),

            ],)
      ),
      Center(child:new Container(
        width: width - 150,
        height: width - 150,
        decoration: BoxDecoration(
          borderRadius: new BorderRadius.all(new Radius.circular(100.0)),

        ),
        child: Stack(
          children: [
            // Example of a hand drawn with [CustomPainter].
            DrawnHand(
              color: customTheme.accentColor,
              thickness: 2,
              size: 0.7,
              angleRadians: _dateTime.second * radiansPerTick,
            ),
            DrawnHand(
              color: customTheme.highlightColor,
              thickness: 3,
              size: 0.6,
              angleRadians: _dateTime.minute * radiansPerTick,
            ),
            // Example of a hand drawn with [Container].
            ContainerHand(
              color: Color.fromRGBO(255, 255, 255, 0.0),
              size: 0.3,
              angleRadians: _dateTime.hour * radiansPerHour +
                  (_dateTime.minute / 60) * radiansPerHour,
              child: Transform.translate(
                offset: Offset(0.0, -100.0),
                child: Container(
                  width: 10,
                  height: 200,
                  decoration: BoxDecoration(
                    color: customTheme.primaryColor,
                  ),
                ),
              ),
            ),

          ],
        ),
      ),),

      ],);
  }
}
